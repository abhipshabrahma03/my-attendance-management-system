# Attendance Management System

## Features
- View student list
- Mark present or absent
- If absent, sends a message using Twilio

## Setup Instructions

1. Clone the repo
2. Go to `/backend` and run `npm install`, add your Twilio credentials in `index.js`, then run `npm start`
3. Go to `/frontend`, run `npm install` then `npm start`
4. The frontend runs on port 3000, backend on 5000

**Make sure Twilio is configured and allowed to message the numbers you use.**
