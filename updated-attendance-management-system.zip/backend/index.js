const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const twilio = require('twilio');

const app = express();
const port = 5000;

const accountSid = 'YOUR_TWILIO_SID';
const authToken = 'YOUR_TWILIO_AUTH_TOKEN';
const client = twilio(accountSid, authToken);

app.use(cors());
app.use(bodyParser.json());

let students = [
  { id: 1, name: 'John Doe', phone: '+1234567890', present: true },
  { id: 2, name: 'Jane Smith', phone: '+1234567891', present: true },
];

app.get('/students', (req, res) => {
  res.json(students);
});

app.post('/attendance', (req, res) => {
  const { id, present } = req.body;
  const student = students.find((s) => s.id === id);
  if (student) {
    student.present = present;
    if (!present) {
      client.messages
        .create({
          body: `Hi ${student.name}, you were marked absent today.`,
          from: 'YOUR_TWILIO_PHONE_NUMBER',
          to: student.phone,
        })
        .then((message) => console.log(message.sid));
    }
    res.json({ success: true });
  } else {
    res.status(404).json({ error: 'Student not found' });
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
